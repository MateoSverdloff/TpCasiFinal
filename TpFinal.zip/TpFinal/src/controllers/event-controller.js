import {Router} from 'express';
import EventService from './../services/event-services.js';
import authMiddleware from '../middlewares/auth-middleware.js';
const router = Router();
const svc    = new EventService();


router.get('', async (req, res) => {
    let respuesta;

    let name = req.query.name;
    let tag = req.query.tag;
    let description = req.query.description;
    let id_creator_user = req.query.id_creator_user;
    let id_event_category = req.query.id_event_category;
    let id_event_location = req.query.id_event_location;
    let duration_in_minutes = req.query.duration_in_minutes;
    let price = req.query.price;
    let enabled_for_enrollment = req.query.enabled_for_enrollment;
    let max_assistance = req.query.max_assistance;
    let start_date = req.query.start_date;

    const returnArray = await svc.getAllAsync(name, tag, description, id_event_category, id_event_location, start_date, duration_in_minutes, price, enabled_for_enrollment, max_assistance, id_creator_user);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });

  // router.get('/:id', async (req, res) => {
  //   let respuesta;
  //   let id = req.params.id;
  //   console.log(id)
  //   const returnArray = await svc.getByIdAsync(id);
  //   if (returnArray != null){
  //     respuesta = res.status(200).json(returnArray);
  //   } else {
  //     respuesta = res.status(500).send(`Error interno.`);
  //   }
  //   return respuesta;
  //  });
   

   router.post('', authMiddleware, async (req, res, next) => { 
    let respuesta;
    let entity = req.body;
    let id_user = req.user.id
    if (!entity.name || !entity.description){
      respuesta = res.status(400).send('Los campos name o description estan vacios.')
    }
  if(entity.name.length < 3 || entity.description.length < 3){
    respuesta = res.status(400).send('Los campos name o description tienen menos de 3 caracteres.')
  }
    const returnArray = await svc.createAsync(entity, id_user);
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });

  router.put('', authMiddleware, async (req, res, next) => {
    let respuesta;
    let entity = req.body;
    const nameRegex = /^[a-zA-Z\s]+$/;
    if (!entity.name || !entity.description){
      respuesta = res.status(400).json('Los campos name o description estan vacios.')
    }
    //aca da el erro HTTP polshu
    if (!nameRegex.test(entity.name)) {
        respuesta = res.status(400).send('El campo name no debe contener números.');
    }
    if(entity.name.length < 3 || entity.description.length < 3){
      respuesta = res.status(400).json('Los campos name o description tienen menos de 3 caracteres.')
    }
    const returnArray = await svc.update2Async(entity);
    if (returnArray == null || returnArray.length < 3) {
      console.log('No se encontro el ID del evento');
      respuesta = res.status(404).json({ success: false, message: 'No se encontro el ID del evento' });
    }
    else if (returnArray != null){
      respuesta = res.status(200).json('Evento actualizado exitosamente');
    }
    return respuesta;
  });

  router.delete('/:id', authMiddleware, async (req, res, next) => {
    let respuesta;
    let entity = req.params.id;
    const returnEntity = await svc.deleteByIdAsync(entity);
    console.log(returnEntity)
    if (returnEntity == null || returnEntity.length < 3) {
      console.log('No se encontro el ID del evento');
      respuesta = res.status(404).json({ success: false, message: 'No se encontro el ID del evento' });
    }
    else if (returnEntity != null){
      respuesta = res.status(200).send('evento eliminado exitosamente');
    }
      return respuesta;
  });

  router.get('/:id', async (req, res) => {
    let respuesta = null;
      const returnArray = await svc.getEventDetails(req.params.id);
      console.log(returnArray)
      if (returnArray != null){
        respuesta = res.status(200).json(returnArray);
      } else {
        respuesta = res.status(404).send(`El id del evento no se encontro.`);
      }
      return respuesta;
  });

  export default router;