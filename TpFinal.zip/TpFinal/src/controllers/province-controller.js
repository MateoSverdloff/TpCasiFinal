import {Router} from 'express';
import ProvinceService from './../services/province-services.js';
import authMiddleware from '../middlewares/auth-middleware.js';
import LocationRouter from "./locations-controller.js"
import LocationsService from './../services/locations-services.js';
const svc2 = new LocationsService();
const router = Router();
const svc    = new ProvinceService();		// Instanciación del Service.

router.get('', async (req, res) => {
  console.log("req")
    let respuesta;
    const returnArray = await svc.getAllAsync();
    if (returnArray != null){
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).send(`Error interno.`);
    }
    return respuesta;
  });
   router.get('/:id', async (req, res) => {
    let id = req.params.id;
    try{
    const returnArray = await svc.getByIdProvince(id);
    if (returnArray == null || returnArray.length < 0) {
      console.log('No se encontro el ID de la provincia:', id);
      res.status(404).json({ success: false, message: 'No se encontro el ID de la provincia' });
  } else {
    res.status(200).json({ success: true, response: returnArray });
  }} catch (error) {
  console.error('Error durante la llamada al servicio:', error);
  res.status(500).json({ success: false, message: 'Error del servicio - getByIdProvince: ' + error.message });
}
   });


router.get('/:id/locations', async (req, res) => {
  let id = req.params.id;
  try{
      const returnArray = await svc2.getByIdLocation(id);
      console.log(returnArray)
      if (returnArray == null || returnArray.length < 0) {
          console.log('No se encontro el ID de la provincia:', id);
          res.status(404).json({ success: false, message: 'No se encontro el ID de la provincia' });
    } else {
        res.status(200).json({ success: true, response: returnArray });
    }} catch (error) {
    console.error('Error durante la llamada al servicio:', error);
    res.status(500).json({ success: false, message: 'Error del servicio - getByIdProvince: ' + error.message });
}
});
//    router.get('/:id/eveprovince', authMiddleware, async (req, res, next) => {
//     let respuesta;
//     let id = req.params.id;
//     let entity = req.body;
//     const returnArray = await svc.getByIdAsync(id);
//     if (returnArray != null){
//       respuesta = res.status(200).json(returnArray);
//     } else {
//       respuesta = res.status(500).send(`Error interno.`);
//     }
//     return respuesta;
//   });

router.post('', async (req, res) => {
    let respuesta;
    let entity = req.body;
    const returnArray = await svc.createAsync(entity);
    if (returnArray != null){
      if (!entity.name){  
        respuesta = res.status(400).json('Los campos name estan vacios.')
      }
    if(entity.name.length < 3){
      respuesta = res.status(400).json('Los campos name tienen menos de 3 caracteres.')
    }
    if(entity.latitude == NaN || entity.longitude == NaN){
      respuesta = res.status(400).json('Latitude o Longitude no son numeros.')
    }
      respuesta = res.status(200).json(returnArray);
    } else {
      respuesta = res.status(500).json(`Error interno.`);
    }
    return respuesta;
  });

  router.put('', async (req, res) => {
    let respuesta;
    let entity = req.body;
      if (!entity.name){
        respuesta = res.status(400).send('Los campos name estan vacios.')
      }
    if(entity.name.length < 3){
      respuesta = res.status(400).send('Los campos name tienen menos de 3 caracteres.')
    }
    if(entity.latitude == NaN || entity.longitude == NaN){
      respuesta = res.status(400).send('Latitude o Longitude no son numeros.')
    }
    const returnArray = await svc.updateAsync(entity);
    console.log(returnArray)
    if (returnArray == null || returnArray.length < 3) {
      console.log('No se encontro el ID de la provincia:', entity.id);
      res.status(404).json({ success: false, message: 'No se encontro el ID de la provincia' });
    }
    else if (returnArray != null){
      respuesta = res.status(200).send(returnArray);
    }
    return respuesta;
    });
  
  router.delete('/:id', async (req, res) => {
    let respuesta;
    let id = req.params.id;
    const returnEntity = await svc.deleteByIdAsync(id);
    console.log(returnEntity)
    if (returnEntity == null || returnEntity.length < 3) {
      console.log('No se encontro el ID de la provincia:', id);
      respuesta = res.status(404).json({ success: false, message: 'No se encontro el ID de la provincia' });
    }
    else if (returnEntity != null){
      respuesta = res.status(200).send('provincia eliminada exitosamente');
    }
      return respuesta;
  });

  export default router;